Here, you can find the source code for my personal website, which can be viewed at mitchelpehora.me. 
All the HTML/Java on there was written by me, so if something doesn't work, let me know! 

I can be contacted on LinkedIn https://www.linkedin.com/in/mitchell-pehora-117b97bb
